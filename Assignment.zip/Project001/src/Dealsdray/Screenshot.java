package Dealsdray;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;

public class Screenshot {

	public static void main(String[] args) throws Exception {

		String url = "https://www.getcalley.com";
		String browser;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the browser you want to exicute");
		browser = sc.next();

		WebDriver driver;

//		FirefoxDriver WebDriver;
		if (browser.equalsIgnoreCase("Firefox"))
			driver = new FirefoxDriver();
		else if (browser.equalsIgnoreCase("Chrome"))
			driver = new ChromeDriver();
		else if (browser.equalsIgnoreCase("Edge"))
			driver = new EdgeDriver();
		else if (browser.equalsIgnoreCase("Opera"))
			driver = new OperaDriver();
		else
			throw new Exception("invalid Browser");

		driver.get(url);
		driver.manage().window().maximize();

		List<int[]> resolutions = Arrays.asList(

				new int[] { 1920, 1080 }, new int[] { 1366, 768 }, new int[] { 1280, 800 }, new int[] { 360, 640 },
				new int[] { 414, 896 }, new int[] { 375, 667 });

		String folderPath = "screenshots";
		File folder = new File(folderPath);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		for (int[] resolution : resolutions) {
			captureScreenshot(driver, url, resolution[0], resolution[1], folderPath, folder);
		}
	}

	public static void captureScreenshot(WebDriver driver, String url, int width, int height, String folderPath,
			File destinationFile) {

		driver.get(url);
		int timeout = 5;
		driver.manage().timeouts().implicitlyWait((long) timeout, TimeUnit.SECONDS);

		driver.manage().window().setSize(new org.openqa.selenium.Dimension(width, height));

		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		File destinationFile1 = new File("D:\\Screenshots\\report_" + System.currentTimeMillis() + ".png");
		try {

			FileHandler.copy(screenshot, destinationFile1);
			System.out.println("Screenshot saved: " + destinationFile1.getAbsolutePath());
		} catch (IOException e) {
			System.err.println("Failed to save screenshot: " + e.getMessage());
		}

	}

}
