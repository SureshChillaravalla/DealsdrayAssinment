package Dealsdray;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.opera.OperaDriver;

public class LinkTraverseSS {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		String url = "https://www.getcalley.com/page-sitemap.xml";
		String browser;
		int n = 5;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the browser you want to exicute");
		browser = sc.next();

		WebDriver driver;
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

//		FirefoxDriver WebDriver;
		if (browser.equalsIgnoreCase("Firefox"))
			driver = new FirefoxDriver();
		else if (browser.equalsIgnoreCase("Chrome"))
			driver = new ChromeDriver();
		else if (browser.equalsIgnoreCase("Edge"))
			driver = new EdgeDriver();
		else if (browser.equalsIgnoreCase("Opera"))
			driver = new OperaDriver();
		else
			throw new Exception("invalid Browser");

		driver.get(url);
		driver.manage().window().maximize();

		WebElement table = driver.findElement(By.id("sitemap"));

		System.out.println(table.findElements(By.tagName("a")).size());

		for (int i = 1; i <= 5; i++) {
			String clickonlink = Keys.chord(Keys.CONTROL, Keys.ENTER);
			table.findElements(By.tagName("a")).get(i).sendKeys(clickonlink);

		}

		Thread.sleep(5000);
		Set<String> abc = driver.getWindowHandles();
		java.util.Iterator<String> it = abc.iterator();

		while (it.hasNext()) {
			driver.switchTo().window(it.next());

			List<int[]> resolutions = Arrays.asList(

					new int[] { 1920, 1080 }, new int[] { 1366, 768 }, new int[] { 1280, 800 }, new int[] { 360, 640 },
					new int[] { 414, 896 }, new int[] { 375, 667 });

			String folderPath = "screenshots";
			File folder = new File(folderPath);
			if (!folder.exists()) {
				folder.mkdirs(); // Create folder if it does not exist
			}
			for (int[] resolution : resolutions) {
				captureScreenshot(driver, url, resolution[0], resolution[1], folderPath, folder);
			}
		}
	}

	public static void captureScreenshot(WebDriver driver, String url, int width, int height, String folderPath,
			File destinationFile) {

		driver.get(url);
		int timeout = 5;
		driver.manage().timeouts().implicitlyWait((long) timeout, TimeUnit.SECONDS);

		driver.manage().window().setSize(new org.openqa.selenium.Dimension(width, height));

		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		File destinationFile1 = new File("D:\\Screenshots\\report_" + System.currentTimeMillis() + ".png");
		try {

			FileHandler.copy(screenshot, destinationFile1);
			System.out.println("Screenshot saved: " + destinationFile1.getAbsolutePath());
		} catch (IOException e) {
			System.err.println("Failed to save screenshot: " + e.getMessage());
		}

	}

}
