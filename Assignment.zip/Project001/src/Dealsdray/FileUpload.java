package Dealsdray;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;

public class FileUpload {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("https://demo.dealsdray.com/");
		driver.manage().window().maximize();

		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("prexo.mis@dealsdray.com");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("prexo.mis@dealsdray.com");
		driver.findElement(By.xpath("//button[@type='submit']")).click();

//		driver.findElement(By.xpath("//span[@class='material-icons notranslate MuiIcon-root MuiIcon-fontSizeMedium icon css-1jgtvd5']")).click();

		driver.findElement(By.xpath("//h3[normalize-space()='54']")).click();

		driver.findElement(By.xpath("//button[text()='Add Bulk Orders']")).click();

		WebElement fileInput = driver.findElement(By.xpath("//input[@type='file']"));

		fileInput.sendKeys("C:\\Users\\Suresh\\Downloads\\demo-data.xlsx");

		driver.findElement(By.xpath("//button[text()='Import']")).click();
		driver.findElement(By.xpath("//button[normalize-space()='Validate Data']")).click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		WebElement dupcount = driver.findElement(By.id("root"));
		System.out.println(dupcount.findElement(By.xpath("(//p[contains(text(),'Order Id Is Duplicate')])")).getSize());

//		JavascriptExecutor js = (JavascriptExecutor) driver;
//		js.executeScript("window.scroll(0,1500)");
//		WebElement targetele =driver.findElement(By.xpath("//h6[@style='margin-top: 19px;']"));
//		js.executeScript("argument[0].scrolltoView();", targetele);
//		js.executeScript("window.scrollBy(500,0)");

		Actions actions = new Actions(driver);
		actions.sendKeys(Keys.PAGE_DOWN).perform();
		Screenshot(driver);
		actions.sendKeys(Keys.PAGE_DOWN).perform();

		Screenshot(driver);

	}

	public static void Screenshot(WebDriver driver) {

		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		File destinationFile1 = new File("D:\\Screenshots\\report_" + System.currentTimeMillis() + ".png");
		try {

			FileHandler.copy(screenshot, destinationFile1);
			System.out.println("Screenshot saved: " + destinationFile1.getAbsolutePath());
		} catch (IOException e) {
			System.err.println("Failed to save screenshot: " + e.getMessage());
		}

	}

}
